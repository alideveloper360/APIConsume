﻿using MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
        
namespace MVC.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult Index()
        {
            IEnumerable<DBModelclass> emplist;
            HttpResponseMessage response = GlobalVariable.webapiclient.GetAsync("Employees").Result;
            emplist = response.Content.ReadAsAsync<IEnumerable<DBModelclass>>().Result;
            
            return View(emplist);
        }
        public ActionResult create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult create(DBModelclass obj)
        {
            HttpResponseMessage response = GlobalVariable.webapiclient.PostAsJsonAsync("Employees/", obj).Result;
            TempData["SuccessMessage"] = "Saved Successfully";
            return RedirectToAction("Index");
        }
        public ActionResult Edit(int id)
        {
            HttpResponseMessage response = GlobalVariable.webapiclient.GetAsync("Employees/" +id.ToString()).Result;
            return View(response.Content.ReadAsAsync<DBModelclass>().Result);
        }
        [HttpPost]
        public ActionResult Edit(DBModelclass obj)
        {
            HttpResponseMessage response = GlobalVariable.webapiclient.PutAsJsonAsync("Employees/"+obj.Empid,obj).Result;
            TempData["SuccessMessage"] = "Update Successfully";

            return RedirectToAction("Index");
        }
        public ActionResult Delete(int id)
        {
            HttpResponseMessage response = GlobalVariable.webapiclient.DeleteAsync("Employees/"+id.ToString()).Result;
            TempData["SuccessMessage"] = "Delete Successfully";
            return RedirectToAction("Index");
        }
        public ActionResult Detail(int id)
        {
            HttpResponseMessage response = GlobalVariable.webapiclient.GetAsync("Employees/" + id.ToString()).Result;
            return View(response.Content.ReadAsAsync<DBModelclass>().Result);
            //return View();
        }
    }
}